package org.example;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import javax.swing.*;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class TemperatureSimulation extends JFrame {

    private static final long serialVersionUID = 1L;

    public TemperatureSimulation(String title) {
        super(title);


        XYSeries temperatureSeries = new XYSeries("Temperature");
        XYSeries setPointSeries = new XYSeries("Set Point");

        // 물리적 상수 및 초기 조건 설정
        double alpha = 1, beta = 40;
        double T_ambient = 20, T_desired = 27, T_start = 21;

        // 시간 간격 설정
        double dt = 0.1;
        double T = T_start;

        // 지정된 이득 및 세트 포인트로 PID 컨트롤러 생성
        PIDController pidController = new PIDController(0.2, 0.15, 0.1, T_desired);

        Random random = new Random();
        Queue<Double> delayQueue = new LinkedList<>();
        int delaySteps = 10; // 딜레이를 원하는 스텝 수로 설정
        
        // 시뮬레이션 루프
        for (int k = 0; k < 100 + delaySteps; k++) {
            if (k < 100) {
                double u = pidController.getControl(T, dt);
                u = Math.max(0, Math.min(1, u));
                
                double noise = 0.05 * random.nextGaussian();
                double T_next = nextTemp(u, T, dt, alpha, beta, T_ambient) + noise;
                delayQueue.add(T_next);
            }

            if (k >= delaySteps) {
                T = delayQueue.remove();
                temperatureSeries.add((k - delaySteps) * dt, T);
                setPointSeries.add((k - delaySteps) * dt, T_desired);
            }
        }

        // 온도 및 세트 포인트 시리즈를 포함하는 XYSeriesCollection 생성
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(temperatureSeries);
        dataset.addSeries(setPointSeries);

        // 데이터셋을 사용하여 라인 차트 생성
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Temperature Simulation",
                "Time",
                "Temperature",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        // ChartPanel 생성 및 크기 설정
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 370));

        // ChartPanel을 JFrame의 콘텐츠 패널로 설정
        setContentPane(chartPanel);
    }

    public static void main(String[] args) {
        // Swing 이벤트 디스패치 스레드에서 시뮬레이션 실행
        SwingUtilities.invokeLater(() -> {
            TemperatureSimulation demo = new TemperatureSimulation("Temperature Simulation");
            demo.pack();
            demo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            demo.setLocationRelativeTo(null);
            demo.setVisible(true);
        });
    }

    // 물리적 모델을 사용하여 다음 온도 계산하는 함수
    private static double nextTemp(double u, double T, double dt, double alpha, double beta, double T_ambient) {
        return T + alpha * (T_ambient - T) * dt + beta * u * dt;
    }
}