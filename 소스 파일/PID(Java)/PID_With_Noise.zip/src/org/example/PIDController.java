package org.example;

class PIDController {
    private double Kp, Ki, Kd, setPoint;
    private double intTerm = 0;
    private double derivativeTerm = 0;
    private Double lastError = null;

    public PIDController(double Kp, double Ki, double Kd, double setPoint) {
        this.Kp = Kp;
        this.Ki = Ki;
        this.Kd = Kd;
        this.setPoint = setPoint;
    }

    public double getControl(double measurement, double dt) {
        double error = setPoint - measurement;
        intTerm += error * Ki * dt;

        if (lastError != null) {
            derivativeTerm = (error - lastError) / dt * Kd;
        }
        lastError = error;

        return Kp * error + intTerm + derivativeTerm;
    }
}